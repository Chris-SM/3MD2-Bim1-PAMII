import { Text, View, StyleSheet, Image } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Image style={styles.logo} source={require('../assets/Nautilus_Vigia.jpg')} />
      /*"Tema as Profundezas" - Nautilus*/
    </View>
  );
}
/* gfdsgdsdsgsdg*/
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#808090',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '10',
    
  },
  logo: {
    height: 180,
    width: 320,
  }
});
