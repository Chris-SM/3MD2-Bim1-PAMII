import { Text, SafeAreaView, StyleSheet } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.Texto1}>
      Cristovão da S. M. dos Santos
      </Text>
      <Card>
        <AssetExample/>
      </Card>
      <Text style={styles.Texto2}>
      Cursando: 3MD2 da Etec Adolpho Berezin
      </Text>
      <Text style={styles.Texto2}>
      Hobbies: Jogar qualquer tipo de jogo e ler
      </Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#808080',
    padding: 8,
  },
  Texto1: {
    margin: 24,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  Texto2: {
    margin: 2,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
