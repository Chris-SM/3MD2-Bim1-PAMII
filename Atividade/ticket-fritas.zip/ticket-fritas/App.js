import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity,TextInput} from 'react-native';

const App = () => {
  const [tempo, setTempo] = useState(0);
  const [dinheiro, setDinheiro] = useState(0);
  const [valorInput, setValorInput] = useState(0);

  useEffect(() => {
    let intervalo = null;
    if (tempo > 0) {
      intervalo = setInterval(() => {
        setTempo((tempo) => tempo - 1);
      }, 1000);
    } else if (tempo === 0) {
      clearInterval(intervalo); 
    }
    return () => clearInterval(intervalo);
  }, [tempo]);

  const add1Min = () =>{
    setTempo((tempo) => tempo + 60);
    setDinheiro((dinheiro)=> dinheiro + 3.00);
  };
  const add2Min = () =>{
    setTempo((tempo) => tempo + 120);
    setDinheiro((dinheiro)=> dinheiro + 5.00);
  };

  const formatarTempo = (tempo) => {
    const minutos = Math.floor(tempo / 60);

    return `${minutos<10 ?'0':''}${minutos}:${tempo%60 < 10 ? '0' : ''}${tempo%60}`;
  };
  const formatarDindin = (dinheiro) => {
    return 'R$: '+`${dinheiro.toFixed(2)}`;
  };

  const muda = (event) => {
    setValorInput(event.nativeEvent.text);
  };

  const addIderteminado = () => {
    var x = parseInt(valorInput)-2;
    if(x==-2)
    {
      alert('Não colocou nada na caixa abaixo?');
      return;
    }
    if(x<0)
    {
      alert("Menor que 2, não sabe ler?");
      return;
    }
    if(x>28)
    {
      alert("Maior que 30, não sabe ler?");
      return;
    }
    var dinheroX = (x*1.50)+5;
    setTempo((tempo) => tempo + (x+2)*60);
    var juros = dinheroX*0.05*Math.floor(((x+2)/10));
    setDinheiro((dinheiro)=> (dinheiro + dinheroX)-juros);
    return ;
  };
  return (
    <View style={styles.corpo}>
      <View style={styles.containerbotoes}>
        <Text style={styles.textoparainderteminado}>Valor de R$3.00</Text>
        <TouchableOpacity style={styles.botao} onPress={add1Min}>
          <Text style={styles.textobotao}>Adicionar 1 Minuto</Text>
        </TouchableOpacity>
        <Text style={styles.textoparainderteminado}>Valor de R$5.00</Text>
        <TouchableOpacity style={styles.botao} onPress={add2Min}>
          <Text style={styles.textobotao}>Adicionar 2 Minutos</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.botaoE} onPress={addIderteminado}>
          <Text style={styles.textobotao}>Adicionar</Text>
        </TouchableOpacity>
        <TextInput style={styles.entrada} id={'inputNum'} onChange={muda} keyboardType="numeric" onSubmitEditing={addIderteminado}></TextInput>
          <Text style={styles.textoparainderteminado}>1 - Tem que ser maior que 1 </Text>
          <Text style={styles.textoparainderteminado}>2 - menor que 31 </Text>
          <Text style={styles.textoparainderteminado}>3 - Primeiro 5 minutos são R$5.00</Text>
          <Text style={styles.textoparainderteminado}>4 - Os minutos subsequentes são R$1.50</Text>
          <Text style={styles.textoparainderteminadoE}>5- a cada cinco reais é descontado 5% do valor (de forma cumulativa)</Text>
      </View>
      <Text style={styles.cronometro}>{formatarTempo(tempo)}</Text>
      <Text style={styles.cronometro}>{formatarDindin(dinheiro)}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  corpo: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  cronometro: {
    fontSize: 48,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  containerbotoes: {
    flexDirection: 'colunm',
    justifyContent: 'space-between',
    width: '70%',
  },
  botao: {
    marginBottom: 10,
    backgroundColor: '#007BFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginHorizontal: 10,
  },
  botaoE: {
    marginTop: 40,
    marginBottom: 10,
    backgroundColor: '#007BFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginHorizontal: 10,
  },
  textobotao: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  textoparainderteminado: {
    fontSize: 12,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 5,
  },
  textoparainderteminadoE: {
    fontSize: 12,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 35,
  },
  entrada: {
    backgroundColor: '#fff000',
    height: 40,
    borderColor: '#000',
    borderStyle: 'solid',
    borderRadius: 6,
    textAlign: 'center',
    color: '#000',
  },
});

export default App;