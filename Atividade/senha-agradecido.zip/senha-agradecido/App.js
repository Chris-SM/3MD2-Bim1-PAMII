import React, {useState} from 'react';

import { Text, SafeAreaView, StyleSheet, Button, View } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';
const realnumber = (classe, numero) => {
  if(numero < 10)
  return classe + '00' + numero;
  if(numero < 100)
  return classe + '0' + numero;
  if(numero > 99)
  return "Sua senha é: "+classe + numero;
};

export default function App() {
  const [normal, setNormal] = useState(1);
  const [priori, setPriori] = useState(1);
  const [alPr, setAlPr] = useState(1);
  var atual = "";
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Selecione Sua Prioridade de atendimento
      </Text>
      <View style={styles.fundoBota}>
        <View style={styles.botao}>
          <Button color="green" title="Normal" onPress={() => {setNormal(normal + 1);atual = realnumber("N",normal);alert("Sua senha é: "+atual)}}/>
        </View>
      <View style={styles.botao}>
        <Button color="orange" title="Prioritário" onPress={() => {setPriori(priori + 1);atual = realnumber("P",priori);alert("Sua senha é: "+atual)}}/>
      </View>
      <View style={styles.botao}>
        <Button color="red" title="Alta Prioridade" onPress={() => {setAlPr(alPr + 1);atual = realnumber("AP",alPr);alert("Sua senha é: "+atual)}}/></View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#F7E9DC',
    padding: 8,
    color: '#5A2616'
  },
  paragraph: {
    margin: 24,
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#5A2616'
  },
  fundoBota: {
    marginVertical: 30,
    flexDirection: "row",
    justifyContent: "space-around",
    color: '#5A2616'
  },
  botao:{
    width: 200,
    color: '#5A2616'
  },
});