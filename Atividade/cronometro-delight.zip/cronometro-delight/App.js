import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity} from 'react-native';

const App = () => {
  const [tempo, setTempo] = useState(0);
  const [ativo, setAtivo] = useState(false);

  useEffect(() => {
    let intervalo = null;
    if (ativo) {
      intervalo = setInterval(() => {
        setTempo((tempo) => tempo + 1);
      }, 1000);
    } else if (!ativo) {
      clearInterval(intervalo); 
    }
    return () => clearInterval(intervalo);
  },[ativo]);

  const add1Min = () =>{
    setAtivo((prevAtivo) => !prevAtivo);
  };
  const add2Min = () =>{
    setTempo(0);
  };

  const formatarTempo = (tempo) => {
    const minutos = Math.floor(tempo / 60);

    return `${minutos<10 ?'0':''}${minutos}:${tempo%60 < 10 ? '0' : ''}${tempo%60}`;
  };

  return (
    <View style={styles.corpo}>
      <Text style={styles.cronometro}>{formatarTempo(tempo)}</Text>
      <View style={styles.containerbotoes}>
        <TouchableOpacity style={styles.botao} onPress={add1Min}>
          <Text style={styles.textobotao}>Começar/Parar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.botao} onPress={add2Min}>
          <Text style={styles.textobotao}>Zerar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  corpo: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  cronometro: {
    fontSize: 48,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  containerbotoes: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    width: '70%',
  },
  botao: {
    marginBottom: 10,
    backgroundColor: '#007BFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginHorizontal: 10,
  },
  textobotao: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default App;